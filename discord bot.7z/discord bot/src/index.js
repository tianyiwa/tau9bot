const { Client, IntentsBitField } = require('discord.js');

// bot permissions
const client = new Client({
 intents: [
    IntentsBitField.Flags.Guilds,
    IntentsBitField.Flags.GuildMembers,
    IntentsBitField.Flags.GuildMessages,
    IntentsBitField.Flags.MessageContent,
 ]
})

const readline = require('readline');


// bot turns on :D
client.once('ready', () => {
    console.log(`${client.user.tag} is now online!`);
    console.log('Type a message in the terminal to send it to the Discord channel.');
  
    // reads what you type in terminal so that the bot says it
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
    });
  
    rl.on('line', (input) => {
      const channel = client.channels.cache.get('1254475153279160430'); 
      if (channel) {
        channel.send(input)
          .then(() => console.log(`Sent: ${input}`))
          .catch(console.error);
      } else {
        console.log('Channel not found!');
      }
    });
  });
  
  
client.on('messageCreate', async (message) => {
  if (message.content.startsWith('!rolegive')) {
      // makes sure whoever sent it has administration role
      const requiredRoleID = '1230571527855149098'; 
      const hasRequiredRole = message.member.roles.cache.has(requiredRoleID);

      if (!hasRequiredRole) {
          return message.reply("You don't have the required role to use this command.");
      }

      // checks who you pinged
      const mentionedUser = message.mentions.members.first();
      if (!mentionedUser) {
          return message.reply('Please mention a user to assign roles to.');
      }

      // the roles it assigns
      const roleIDs = [
          '1232327547958726707', //roles
          '1230570855499567126',
          '1231314178027950090',
          '1231314517057863841',
          '1231314745966071848',
          
      ];

      try {
          for (const roleID of roleIDs) {
              const role = message.guild.roles.cache.get(roleID);
              if (role) {
                  await mentionedUser.roles.add(role);
              } else {
                  console.warn(`Role with ID ${roleID} not found.`);
                }
              }
              await message.reply(`${mentionedUser}, welcome to Mobile Task Force τau-9! We hope you have a good stay. Be sure to request a codename in https://discord.com/channels/1229844708914630768/1230572558106234960, a morph from https://discord.com/channels/1229844708914630768/1230571619169206272 and put it in https://discord.com/channels/1229844708914630768/1230571949646676141.`);
        
              // delete message
              await message.delete();
            } catch (error) {
          console.error('Error assigning roles:', error);
          message.reply('There was an error assigning the roles. Please check the bot permissions and role hierarchy.');
      }
  }
});

// bot token
client.login(
    "MTMxNTg2MzM4OTEyNTM0OTM5Ng.GrU8BL.1N140g339cHXZHIiI4znJGqrRH6ejpVm3GZlqE"

);
